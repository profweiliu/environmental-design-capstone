# Create a new directory
mkdir -p new_folder_script

# Enter the new folder
cd new_folder_script

# 6. Create an empty text file
touch using_script.txt

